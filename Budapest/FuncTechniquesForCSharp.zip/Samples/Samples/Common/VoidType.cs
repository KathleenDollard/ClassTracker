﻿namespace KadGen.Functional.Common
{
    public class VoidType
    {
    }
}
