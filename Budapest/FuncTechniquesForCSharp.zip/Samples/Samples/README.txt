Thanks for coming to my talk! 

This code is demo code, so there's no warranty of any kind. 

I failed to shout out to the awesome material in my references. 
The videos and book cover similar concepts from other perspectives.

I cut short an important demo, so I included the final code here. 
You'll find this in the InsideOutRecfactoring class where you 
can compare the before and after versions. 

Enjoy!